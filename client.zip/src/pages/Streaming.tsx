import StreamingInterface from '@/components/StreamingInterface';

const Streaming = () => {
  return <StreamingInterface />;
};

export default Streaming;