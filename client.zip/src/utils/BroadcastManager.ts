interface ICEServerConfig {
  iceServers: RTCIceServer[];
  hasTURN: boolean;
  warning?: string;
}

interface ConnectionQuality {
  quality: 'excellent' | 'good' | 'fair' | 'poor';
  packetLoss: number;
  rtt: number;
  bitrate: number;
}

export class BroadcastManager {
  private peerConnections: Map<string, RTCPeerConnection> = new Map();
  private localStream: MediaStream | null = null;
  private channel: any = null;
  private dbSignalingChannel: any = null;
  private streamId: string;
  private viewerMetadata: Map<string, { name: string; joinedAt: Date; isGuest: boolean }> = new Map();
  private broadcasterReadyInterval: NodeJS.Timeout | null = null;
  private retryAttempts: Map<string, number> = new Map();
  private iceConfig: ICEServerConfig | null = null;
  private iceConfigExpiry: number = 0;
  private answerReceived: Map<string, boolean> = new Map();
  private offerAcked: Map<string, boolean> = new Map();
  private offerRetryTimers: Map<string, NodeJS.Timeout> = new Map();
  private lastSignalingEvents: Array<{time: string, event: string}> = [];
  private onChannelStatusChange?: (status: 'connecting' | 'connected' | 'error' | 'closed') => void;
  private qualityMonitoringInterval: NodeJS.Timeout | null = null;
  private connectionQuality: Map<string, ConnectionQuality> = new Map();
  private dbPollingInterval: NodeJS.Timeout | null = null;
  private lastProcessedSignalId: string | null = null;
  private processedSignalIds: Set<string> = new Set();
  private isInitialPollComplete: boolean = false;
  private fullScanInterval: NodeJS.Timeout | null = null;
  private supabaseClient: any = null;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 5;
  private reconnectTimeout: NodeJS.Timeout | null = null;
  private healthCheckInterval: NodeJS.Timeout | null = null;
  private lastHealthyTimestamp: number = Date.now();
  
  constructor(streamId: string, localStream: MediaStream) {
    this.streamId = streamId;
    this.localStream = localStream;
    
    // Validate stream has required tracks
    this.validateStream();
  }
  
  private validateStream() {
    if (!this.localStream) {
      throw new Error('No local stream provided');
    }
    
    const videoTracks = this.localStream.getVideoTracks();
    const audioTracks = this.localStream.getAudioTracks();
    
    console.log('🎥 BroadcastManager stream validation:');
    console.log(`  Video tracks: ${videoTracks.length}`);
    console.log(`  Audio tracks: ${audioTracks.length}`);
    
    videoTracks.forEach((track, i) => {
      console.log(`  Video ${i}: enabled=${track.enabled}, state=${track.readyState}, label="${track.label}"`);
    });
    
    audioTracks.forEach((track, i) => {
      console.log(`  Audio ${i}: enabled=${track.enabled}, state=${track.readyState}, label="${track.label}"`);
    });
    
    if (videoTracks.length === 0) {
      throw new Error('No video track in stream - camera required for broadcasting');
    }
    
    const videoTrack = videoTracks[0];
    if (!videoTrack.enabled) {
      throw new Error('Video track is disabled - please enable camera');
    }
    
    if (videoTrack.readyState !== 'live') {
      throw new Error(`Video track not live (state: ${videoTrack.readyState})`);
    }
    
    console.log('✅ Stream validation passed');
  }

  private async fetchIceServers(supabase: any): Promise<ICEServerConfig> {
    if (this.iceConfig && Date.now() < this.iceConfigExpiry) {
      return this.iceConfig;
    }

    try {
      const { data, error } = await supabase.functions.invoke('get-ice-servers');
      
      if (error) throw error;
      
      this.iceConfig = data;
      this.iceConfigExpiry = Date.now() + 5 * 60 * 1000;
      
      if (data.warning) {
        console.warn('⚠️ ICE server warning:', data.warning);
      }
      
      console.log('🔍 ICE Config fetched:', {
        hasTURN: data.hasTURN,
        serverCount: data.iceServers?.length,
        servers: data.iceServers?.map((s: RTCIceServer) => s.urls)
      });
      
      return data;
    } catch (error) {
      console.error('Failed to fetch ICE servers, using STUN fallback:', error);
      
      return {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' }
        ],
        hasTURN: false,
        warning: 'Failed to load TURN config'
      };
    }
  }

  private async monitorConnectionQuality(sessionToken: string, pc: RTCPeerConnection) {
    try {
      const stats = await pc.getStats();
      let packetLoss = 0;
      let rtt = 0;
      let bitrate = 0;

      for (const report of stats.values()) {
        if (report.type === 'outbound-rtp' && report.kind === 'video') {
          const sent = report.packetsSent || 0;
          const retransmitted = report.retransmittedPacketsSent || 0;
          if (sent > 0) {
            packetLoss = (retransmitted / sent) * 100;
          }
          bitrate = (report.bytesSent || 0) * 8 / 1000; // kbps
        }

        if (report.type === 'candidate-pair' && report.state === 'succeeded') {
          rtt = report.currentRoundTripTime ? report.currentRoundTripTime * 1000 : 0;
        }
      }

      let quality: 'excellent' | 'good' | 'fair' | 'poor' = 'excellent';
      if (packetLoss > 5 || rtt > 300) {
        quality = 'poor';
        await this.adjustBitrate(pc, 'poor');
      } else if (packetLoss > 2 || rtt > 200) {
        quality = 'fair';
        await this.adjustBitrate(pc, 'fair');
      } else if (packetLoss > 1 || rtt > 100) {
        quality = 'good';
        await this.adjustBitrate(pc, 'good');
      }

      this.connectionQuality.set(sessionToken, { quality, packetLoss, rtt, bitrate });
      
      if (quality === 'poor') {
        console.warn(`⚠️ Poor connection quality for ${sessionToken.substring(0, 8)}: ${packetLoss.toFixed(1)}% loss, ${rtt.toFixed(0)}ms RTT`);
      }
    } catch (error) {
      console.error('Error monitoring connection quality:', error);
    }
  }

  private async adjustBitrate(pc: RTCPeerConnection, quality: 'excellent' | 'good' | 'fair' | 'poor') {
    const bitrateMap = {
      excellent: 2500000, // 2.5 Mbps
      good: 1500000,      // 1.5 Mbps
      fair: 800000,       // 800 Kbps
      poor: 400000        // 400 Kbps
    };

    try {
      const senders = pc.getSenders();
      const videoSender = senders.find(s => s.track?.kind === 'video');
      
      if (videoSender) {
        const params = videoSender.getParameters();
        if (!params.encodings) params.encodings = [{}];
        params.encodings[0].maxBitrate = bitrateMap[quality];
        await videoSender.setParameters(params);
        console.log(`📊 Adjusted bitrate to ${(bitrateMap[quality] / 1000000).toFixed(1)} Mbps (${quality})`);
      }
    } catch (error) {
      console.error('Error adjusting bitrate:', error);
    }
  }

  getConnectionQuality(sessionToken: string): ConnectionQuality | undefined {
    return this.connectionQuality.get(sessionToken);
  }

  private logSignalingEvent(event: string) {
    const time = new Date().toISOString().split('T')[1].slice(0, 12);
    this.lastSignalingEvents.push({ time, event });
    if (this.lastSignalingEvents.length > 20) {
      this.lastSignalingEvents.shift();
    }
  }

  getLastSignalingEvents() {
    return [...this.lastSignalingEvents];
  }

  setChannelStatusHandler(callback: (status: 'connecting' | 'connected' | 'error' | 'closed') => void) {
    this.onChannelStatusChange = callback;
  }

  async initializeChannel(supabase: any) {
    this.supabaseClient = supabase;
    this.onChannelStatusChange?.('connecting');
    await this.fetchIceServers(supabase);
    
    // Start health check monitoring
    this.startHealthCheckMonitoring();
    
    // Start database polling FIRST as primary signaling mechanism
    this.startDbPolling(supabase);
    
    this.channel = supabase
      .channel(`live_stream_${this.streamId}`, {
        config: {
          broadcast: { ack: true },
          presence: { key: `broadcaster:${this.streamId}` }
        }
      })
      .on('broadcast', { event: 'viewer-joined' }, (payload: any) => this.handleViewerJoined(payload, supabase))
      .on('broadcast', { event: 'offer-received' }, this.handleOfferReceived)
      .on('broadcast', { event: 'request-offer' }, (payload: any) => this.handleRequestOffer(payload, supabase))
      .on('broadcast', { event: 'answer' }, this.handleAnswer)
      .on('broadcast', { event: 'ice-candidate' }, this.handleICECandidate)
      .on('broadcast', { event: 'viewer-left' }, this.handleViewerLeft)
      .subscribe(async (status: string) => {
        this.logSignalingEvent(`Channel: ${status}`);
        
        if (status === 'SUBSCRIBED') {
          console.log('✓ Broadcaster channel ready, broadcasting ready signal');
          this.onChannelStatusChange?.('connected');
          
          // Immediate catch-up query for any missed viewer signals
          console.log('🔍 Running catch-up query for missed viewer signals...');
          await this.runCatchUpQuery(supabase);
          
          // Write broadcaster-ready to database immediately
          await this.sendSignalViaDb(supabase, 'broadcaster', 'broadcaster_ready', { streamId: this.streamId });
          
          // Also broadcast via realtime as backup
          const result = await this.sendSignal('broadcaster-ready', { streamId: this.streamId });
          if (result !== 'ok') {
            console.warn('⚠️ broadcaster-ready broadcast failed (DB already sent)');
          }
          
          // Periodically write to database for reliability
          this.broadcasterReadyInterval = setInterval(async () => {
            await this.sendSignalViaDb(supabase, 'broadcaster', 'broadcaster_ready', { streamId: this.streamId });
            await this.sendSignal('broadcaster-ready', { streamId: this.streamId });
          }, 3000);
          
          // Start periodic full scan every 30s to catch any missed signals
          this.fullScanInterval = setInterval(() => {
            console.log('🔍 Running periodic full scan...');
            this.runFullScan(supabase);
          }, 30000);
        } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
          console.warn(`⚠️ Channel status: ${status}, attempting reconnection...`);
          this.onChannelStatusChange?.('error');
          this.attemptReconnect(supabase);
        } else if (status === 'CLOSED') {
          console.warn(`⚠️ Channel closed, attempting reconnection...`);
          this.onChannelStatusChange?.('closed');
          this.attemptReconnect(supabase);
        }
      });

    this.setupDbSignalingFallback(supabase);
  }

  private startDbPolling(supabase: any) {
    console.log('🔄 Starting database polling for viewer signals (every 2s)');
    
    const pollDatabase = async () => {
      try {
        // On initial poll, get ALL signals (no timestamp filter)
        // After that, only get new ones
        const query = supabase
          .from('webrtc_signals')
          .select('*')
          .eq('stream_id', this.streamId)
          .eq('role', 'viewer')
          .order('created_at', { ascending: true })
          .limit(50);
        
        // Only filter by timestamp after initial poll is complete
        if (this.isInitialPollComplete && this.lastProcessedSignalId) {
          query.gt('created_at', this.lastProcessedSignalId);
        }
        
        const { data: signals, error } = await query;
        
        if (error) {
          console.error('❌ DB poll error:', error);
          return;
        }
        
        const pollType = this.isInitialPollComplete ? 'incremental' : 'initial';
        console.log(`📊 DB poll (${pollType}): found ${signals?.length || 0} signals`);
        
        if (signals && signals.length > 0) {
          console.log(`📨 Processing ${signals.length} viewer signal(s)`);
          
          let processedCount = 0;
          for (const signal of signals) {
            // Skip if already processed (deduplication)
            if (this.processedSignalIds.has(signal.id)) {
              continue;
            }
            
            try {
              // Process signal based on type
              if (signal.type === 'viewer_joined') {
                console.log('📨 DB: viewer joined', signal.session_token?.substring(0, 8));
                await this.handleViewerJoined({ payload: signal.payload }, supabase);
                processedCount++;
              } else if (signal.type === 'request_offer') {
                console.log('📨 DB: offer requested', signal.session_token?.substring(0, 8));
                await this.handleRequestOffer({ payload: signal.payload }, supabase);
                processedCount++;
              } else if (signal.type === 'answer') {
                console.log('📨 DB: answer received', signal.session_token?.substring(0, 8));
                await this.handleAnswer({ payload: signal.payload });
                processedCount++;
              } else if (signal.type === 'ice') {
                await this.handleICECandidate({ payload: signal.payload });
                processedCount++;
              }
              
              // Mark as processed
              this.processedSignalIds.add(signal.id);
              this.lastProcessedSignalId = signal.created_at;
            } catch (signalError) {
              console.error(`❌ Error processing signal ${signal.id}:`, signalError);
              // Continue processing other signals even if one fails
            }
          }
          
          if (processedCount > 0) {
            console.log(`✅ Successfully processed ${processedCount}/${signals.length} signals`);
          }
        }
        
        // Mark initial poll as complete after first run
        if (!this.isInitialPollComplete) {
          this.isInitialPollComplete = true;
          console.log('✅ Initial DB poll complete, switching to incremental mode');
        }
      } catch (err) {
        console.error('❌ DB polling error:', err);
      }
    };
    
    // Poll immediately, then every 2 seconds
    pollDatabase();
    this.dbPollingInterval = setInterval(pollDatabase, 2000);
  }

  private async runCatchUpQuery(supabase: any) {
    try {
      const { data: signals, error } = await supabase
        .from('webrtc_signals')
        .select('*')
        .eq('stream_id', this.streamId)
        .eq('role', 'viewer')
        .order('created_at', { ascending: true })
        .limit(50);
      
      if (error) {
        console.error('❌ Catch-up query error:', error);
        return;
      }
      
      console.log(`📊 Catch-up found ${signals?.length || 0} total signals`);
      
      if (signals && signals.length > 0) {
        let caughtUp = 0;
        for (const signal of signals) {
          if (!this.processedSignalIds.has(signal.id)) {
            try {
              if (signal.type === 'viewer_joined') {
                await this.handleViewerJoined({ payload: signal.payload }, supabase);
                caughtUp++;
              } else if (signal.type === 'request_offer') {
                await this.handleRequestOffer({ payload: signal.payload }, supabase);
                caughtUp++;
              }
              this.processedSignalIds.add(signal.id);
            } catch (err) {
              console.error(`❌ Error in catch-up processing:`, err);
            }
          }
        }
        if (caughtUp > 0) {
          console.log(`✅ Caught up with ${caughtUp} missed signals`);
        }
      }
    } catch (err) {
      console.error('❌ Catch-up query failed:', err);
    }
  }

  private async runFullScan(supabase: any) {
    try {
      const { data: signals, error } = await supabase
        .from('webrtc_signals')
        .select('*')
        .eq('stream_id', this.streamId)
        .eq('role', 'viewer')
        .in('type', ['viewer_joined', 'request_offer'])
        .order('created_at', { ascending: true })
        .limit(100);
      
      if (error) {
        console.error('❌ Full scan error:', error);
        return;
      }
      
      let newSignals = 0;
      if (signals && signals.length > 0) {
        for (const signal of signals) {
          if (!this.processedSignalIds.has(signal.id)) {
            try {
              if (signal.type === 'viewer_joined') {
                await this.handleViewerJoined({ payload: signal.payload }, supabase);
                newSignals++;
              } else if (signal.type === 'request_offer') {
                await this.handleRequestOffer({ payload: signal.payload }, supabase);
                newSignals++;
              }
              this.processedSignalIds.add(signal.id);
            } catch (err) {
              console.error(`❌ Error in full scan processing:`, err);
            }
          }
        }
      }
      
      if (newSignals > 0) {
        console.log(`✅ Full scan found ${newSignals} new signals`);
      }
    } catch (err) {
      console.error('❌ Full scan failed:', err);
    }
  }

  private setupDbSignalingFallback(supabase: any) {
    // Keep realtime as backup for instant notifications
    this.dbSignalingChannel = supabase
      .channel('db-signaling-broadcaster')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'webrtc_signals',
          filter: `stream_id=eq.${this.streamId}`
        },
        async (payload: any) => {
          const signal = payload.new;
          
          // Only process if DB polling hasn't already handled it
          if (signal.type === 'viewer_joined' && signal.role === 'viewer') {
            console.log('📨 Realtime: viewer joined', signal.session_token);
            await this.handleViewerJoined({ payload: signal.payload }, supabase);
          } else if (signal.type === 'request_offer' && signal.role === 'viewer') {
            console.log('📨 Realtime: offer requested', signal.session_token);
            await this.handleRequestOffer({ payload: signal.payload }, supabase);
          } else if (signal.type === 'answer' && signal.role === 'viewer') {
            console.log('📨 Realtime: answer received', signal.session_token);
            await this.handleAnswer({ payload: signal.payload });
          } else if (signal.type === 'ice' && signal.role === 'viewer') {
            await this.handleICECandidate({ payload: signal.payload });
          }
        }
      )
      .subscribe();
  }

  private async sendSignalViaDb(supabase: any, sessionToken: string, type: string, payload: any) {
    try {
      await supabase.from('webrtc_signals').insert({
        stream_id: this.streamId,
        session_token: sessionToken,
        role: 'broadcaster',
        type,
        payload
      });
      console.log(`✓ Sent ${type} via DB to ${sessionToken.substring(0, 8)}`);
    } catch (err) {
      console.error('DB signal send failed:', err);
    }
  }

  private handleViewerJoined = async ({ payload }: any, supabase: any) => {
    const { sessionToken, displayName, isGuest } = payload;
    console.log(`👤 Viewer joined: ${displayName} (${sessionToken.substring(0, 8)}...)`);
    this.logSignalingEvent(`Viewer joined: ${displayName}`);
    
    this.viewerMetadata.set(sessionToken, {
      name: displayName || 'Anonymous',
      joinedAt: new Date(),
      isGuest: isGuest || false
    });

    const ackResult = await this.sendSignal('viewer-ack', { sessionToken });
    if (ackResult !== 'ok') {
      console.warn('⚠️ viewer-ack send failed, using DB');
      await this.sendSignalViaDb(supabase, sessionToken, 'viewer_ack', { sessionToken });
    }
    console.log(`✓ Sent viewer-ack to ${sessionToken.substring(0, 8)}...`);
    
    const existingPeer = this.peerConnections.get(sessionToken);
    if (existingPeer && existingPeer.connectionState !== 'failed' && existingPeer.connectionState !== 'closed') {
      console.log(`⚠️ Peer already exists for ${sessionToken.substring(0, 8)}... (${existingPeer.connectionState})`);
      return;
    }
    
    this.retryAttempts.set(sessionToken, 0);
    await this.createPeerConnection(sessionToken, false, supabase);
  };

  private handleOfferReceived = ({ payload }: any) => {
    const { sessionToken } = payload;
    console.log(`✓ Offer received ACK from ${sessionToken?.substring(0, 8)}...`);
    this.logSignalingEvent(`Offer ACK: ${sessionToken?.substring(0, 8)}`);
    
    this.offerAcked.set(sessionToken, true);
    
    const timer = this.offerRetryTimers.get(sessionToken);
    if (timer) {
      clearTimeout(timer);
      this.offerRetryTimers.delete(sessionToken);
    }
  };

  private handleRequestOffer = async ({ payload }: any, supabase: any) => {
    const { sessionToken } = payload;
    console.log(`🔔 Viewer ${sessionToken?.substring(0, 8)}... requesting offer`);
    this.logSignalingEvent(`Offer requested: ${sessionToken?.substring(0, 8)}`);
    
    const pc = this.peerConnections.get(sessionToken);
    if (pc) {
      const offer = await pc.createOffer({
        offerToReceiveAudio: true,
        offerToReceiveVideo: true,
        iceRestart: true
      });
      await pc.setLocalDescription(offer);

      console.log(`📤 Re-sending offer to ${sessionToken.substring(0, 8)}...`);
      const result = await this.sendSignal('offer', { offer, sessionToken });
      
      if (result !== 'ok') {
        console.warn('⚠️ Offer resend failed, using DB');
        await this.sendSignalViaDb(supabase, sessionToken, 'offer', { offer, sessionToken });
      }
    } else {
      console.log(`📤 Creating new connection for ${sessionToken.substring(0, 8)}...`);
      await this.createPeerConnection(sessionToken, false, supabase);
    }
  };

  private async createPeerConnection(sessionToken: string, useRelayOnly: boolean, supabase: any) {
    try {
      const iceConfig = await this.fetchIceServers(supabase);
      
      const pcConfig: RTCConfiguration = {
        iceServers: useRelayOnly && iceConfig.hasTURN
          ? iceConfig.iceServers.filter(server => 
              server.urls?.toString().includes('turn')
            )
          : iceConfig.iceServers,
        iceTransportPolicy: useRelayOnly ? 'relay' : 'all',
        iceCandidatePoolSize: 10
      };

      const pc = new RTCPeerConnection(pcConfig);
      
      // Start monitoring connection quality every 3 seconds
      if (!this.qualityMonitoringInterval) {
        this.qualityMonitoringInterval = setInterval(() => {
          this.peerConnections.forEach((pc, token) => {
            if (pc.connectionState === 'connected') {
              this.monitorConnectionQuality(token, pc);
            }
          });
        }, 3000);
      }
      
      pc.onconnectionstatechange = () => {
        console.log(`🔗 Peer ${sessionToken.substring(0, 8)}... connection: ${pc.connectionState}`);
        
        if (pc.connectionState === 'failed') {
          console.warn(`❌ Connection failed for ${sessionToken.substring(0, 8)}...`);
          
          const attempts = this.retryAttempts.get(sessionToken) || 0;
          if (attempts < 2 && !useRelayOnly && iceConfig.hasTURN) {
            console.log(`🔄 Retrying with TURN for ${sessionToken.substring(0, 8)}...`);
            this.retryAttempts.set(sessionToken, attempts + 1);
            this.removePeerConnection(sessionToken);
            setTimeout(() => {
              this.createPeerConnection(sessionToken, true, supabase);
            }, 1000);
          } else {
            this.removePeerConnection(sessionToken);
          }
        } else if (pc.connectionState === 'connected') {
          console.log(`✅ Connected to ${sessionToken.substring(0, 8)}...`);
          this.retryAttempts.delete(sessionToken);
        }
      };

      pc.onicecandidate = async (event) => {
        if (event.candidate) {
          console.log(`🧊 Sending ICE to ${sessionToken.substring(0, 8)}...`);
          
          const result = await this.sendSignal('ice-candidate', {
            candidate: event.candidate,
            sessionToken
          });

          if (result !== 'ok') {
            console.warn('⚠️ ICE send failed, using DB');
            await this.sendSignalViaDb(supabase, sessionToken, 'ice', {
              candidate: event.candidate,
              sessionToken
            });
          }
        }
      };

      if (this.localStream) {
        this.localStream.getTracks().forEach(track => {
          if (this.localStream) {
            pc.addTrack(track, this.localStream);
          }
        });
      }

      this.peerConnections.set(sessionToken, pc);
      this.answerReceived.set(sessionToken, false);
      this.offerAcked.set(sessionToken, false);

      // Create offer - let WebRTC infer media from addTrack() calls
      const offer = await pc.createOffer();
      
      await pc.setLocalDescription(offer);

      console.log(`📤 Sending offer to ${sessionToken.substring(0, 8)}...${useRelayOnly ? ' (TURN only)' : ''}`);
      
      const result = await this.sendSignal('offer', { offer, sessionToken });
      
      if (result !== 'ok') {
        console.warn('⚠️ Initial offer send failed, using DB');
        await this.sendSignalViaDb(supabase, sessionToken, 'offer', { offer, sessionToken });
      }

      let retryCount = 0;
      const maxRetries = 5;
      
      const retryTimer = setInterval(async () => {
        const acked = this.offerAcked.get(sessionToken);
        const answered = this.answerReceived.get(sessionToken);
        
        if (acked || answered) {
          console.log(`✓ Offer delivered to ${sessionToken.substring(0, 8)}... (${acked ? 'acked' : 'answered'})`);
          clearInterval(retryTimer);
          this.offerRetryTimers.delete(sessionToken);
          return;
        }

        retryCount++;
        if (retryCount >= maxRetries) {
          console.warn(`⚠️ Max offer retries for ${sessionToken.substring(0, 8)}...`);
          clearInterval(retryTimer);
          this.offerRetryTimers.delete(sessionToken);
          
          await this.sendSignal('request-offer-ready', { sessionToken });
          return;
        }

        console.log(`🔁 Resending offer to ${sessionToken.substring(0, 8)}... (attempt ${retryCount}/${maxRetries})`);
        const retryResult = await this.sendSignal('offer', { offer, sessionToken });
        
        if (retryResult !== 'ok' && retryCount > 2) {
          await this.sendSignalViaDb(supabase, sessionToken, 'offer', { offer, sessionToken });
        }
      }, 2000);

      this.offerRetryTimers.set(sessionToken, retryTimer);

    } catch (error) {
      console.error(`Error creating peer connection for ${sessionToken.substring(0, 8)}:`, error);
      this.removePeerConnection(sessionToken);
    }
  }

  private handleAnswer = async ({ payload }: any) => {
    const { answer, sessionToken } = payload;
    const pc = this.peerConnections.get(sessionToken);

    if (pc) {
      try {
        await pc.setRemoteDescription(new RTCSessionDescription(answer));
        console.log(`✅ Answer set for ${sessionToken.substring(0, 8)}...`);
        this.logSignalingEvent(`Answer set: ${sessionToken.substring(0, 8)}`);
        
        this.answerReceived.set(sessionToken, true);
        
        const timer = this.offerRetryTimers.get(sessionToken);
        if (timer) {
          clearTimeout(timer);
          this.offerRetryTimers.delete(sessionToken);
        }
      } catch (error) {
        console.error(`Error setting answer for ${sessionToken.substring(0, 8)}:`, error);
      }
    }
  };

  private handleICECandidate = async ({ payload }: any) => {
    const { candidate, sessionToken } = payload;
    const pc = this.peerConnections.get(sessionToken);

    if (pc && candidate) {
      try {
        await pc.addIceCandidate(new RTCIceCandidate(candidate));
        console.log(`🧊 ICE added for ${sessionToken.substring(0, 8)}...`);
      } catch (error) {
        console.error(`Error adding ICE for ${sessionToken.substring(0, 8)}:`, error);
      }
    }
  };

  private handleViewerLeft = ({ payload }: any) => {
    const { sessionToken } = payload;
    console.log(`👋 Viewer left: ${sessionToken?.substring(0, 8)}...`);
    this.logSignalingEvent(`Viewer left: ${sessionToken?.substring(0, 8)}`);
    this.removePeerConnection(sessionToken);
    this.viewerMetadata.delete(sessionToken);
  };

  private async sendSignal(event: string, payload: any): Promise<string> {
    if (!this.channel) return 'error';
    
    try {
      const result = await this.channel.send({
        type: 'broadcast',
        event,
        payload
      });
      
      this.logSignalingEvent(`Sent: ${event}`);
      return result;
    } catch (err) {
      console.error(`Failed to send ${event}:`, err);
      return 'error';
    }
  }

  private removePeerConnection(sessionToken: string) {
    const pc = this.peerConnections.get(sessionToken);
    if (pc) {
      pc.close();
      this.peerConnections.delete(sessionToken);
    }
    
    const timer = this.offerRetryTimers.get(sessionToken);
    if (timer) {
      clearTimeout(timer);
      this.offerRetryTimers.delete(sessionToken);
    }
    
    this.retryAttempts.delete(sessionToken);
    this.answerReceived.delete(sessionToken);
    this.offerAcked.delete(sessionToken);
  }

  private startHealthCheckMonitoring() {
    console.log('💓 Starting health check monitoring');
    
    this.healthCheckInterval = setInterval(() => {
      const now = Date.now();
      const timeSinceHealthy = now - this.lastHealthyTimestamp;
      
      // Check if channel is still subscribed
      const isChannelHealthy = this.channel?.state === 'joined';
      
      if (isChannelHealthy) {
        this.lastHealthyTimestamp = now;
        this.reconnectAttempts = 0; // Reset on successful health check
      } else if (timeSinceHealthy > 15000) { // 15 seconds without healthy connection
        console.warn('⚠️ Channel unhealthy for 15s, triggering reconnect');
        if (this.supabaseClient) {
          this.attemptReconnect(this.supabaseClient);
        }
      }
      
      // Log health status
      console.log('💓 Health check:', {
        channelState: this.channel?.state,
        timeSinceHealthy: `${(timeSinceHealthy / 1000).toFixed(1)}s`,
        reconnectAttempts: this.reconnectAttempts,
        peerConnections: this.peerConnections.size
      });
    }, 10000); // Check every 10 seconds
  }

  private attemptReconnect(supabase: any) {
    // Prevent multiple simultaneous reconnection attempts
    if (this.reconnectTimeout) {
      console.log('⏳ Reconnect already in progress');
      return;
    }
    
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('❌ Max reconnection attempts reached');
      this.onChannelStatusChange?.('error');
      return;
    }
    
    this.reconnectAttempts++;
    const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts - 1), 30000); // Exponential backoff, max 30s
    
    console.log(`🔄 Scheduling reconnect attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${delay}ms`);
    
    this.reconnectTimeout = setTimeout(async () => {
      this.reconnectTimeout = null;
      await this.reconnectChannel(supabase);
    }, delay);
  }

  private async reconnectChannel(supabase: any) {
    console.log('🔄 Reconnecting channel...');
    this.onChannelStatusChange?.('connecting');
    
    try {
      // Unsubscribe old channel
      if (this.channel) {
        await supabase.removeChannel(this.channel);
        this.channel = null;
      }
      
      // Recreate channel with same configuration
      this.channel = supabase
        .channel(`live_stream_${this.streamId}`, {
          config: {
            broadcast: { ack: true },
            presence: { key: `broadcaster:${this.streamId}` }
          }
        })
        .on('broadcast', { event: 'viewer-joined' }, (payload: any) => this.handleViewerJoined(payload, supabase))
        .on('broadcast', { event: 'offer-received' }, this.handleOfferReceived)
        .on('broadcast', { event: 'request-offer' }, (payload: any) => this.handleRequestOffer(payload, supabase))
        .on('broadcast', { event: 'answer' }, this.handleAnswer)
        .on('broadcast', { event: 'ice-candidate' }, this.handleICECandidate)
        .on('broadcast', { event: 'viewer-left' }, this.handleViewerLeft)
        .subscribe(async (status: string) => {
          this.logSignalingEvent(`Reconnect: ${status}`);
          
          if (status === 'SUBSCRIBED') {
            console.log('✅ Channel reconnected successfully');
            this.onChannelStatusChange?.('connected');
            this.lastHealthyTimestamp = Date.now();
            this.reconnectAttempts = 0;
            
            // Re-announce broadcaster ready
            await this.sendSignalViaDb(supabase, 'broadcaster', 'broadcaster_ready', { streamId: this.streamId });
            await this.sendSignal('broadcaster-ready', { streamId: this.streamId });
          } else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT') {
            console.warn(`⚠️ Reconnect failed: ${status}`);
            this.attemptReconnect(supabase);
          }
        });
      
    } catch (error) {
      console.error('❌ Reconnection error:', error);
      this.onChannelStatusChange?.('error');
      this.attemptReconnect(supabase);
    }
  }

  checkChannelHealth(): { isHealthy: boolean; details: any } {
    const isChannelHealthy = this.channel?.state === 'joined';
    const timeSinceHealthy = Date.now() - this.lastHealthyTimestamp;
    
    return {
      isHealthy: isChannelHealthy && timeSinceHealthy < 20000,
      details: {
        channelState: this.channel?.state,
        timeSinceHealthyMs: timeSinceHealthy,
        reconnectAttempts: this.reconnectAttempts,
        peerConnections: this.peerConnections.size,
        hasSupabaseClient: !!this.supabaseClient
      }
    };
  }

  cleanup() {
    console.log('🧹 Cleaning up broadcast manager');
    
    // Clear quality monitoring
    if (this.qualityMonitoringInterval) {
      clearInterval(this.qualityMonitoringInterval);
      this.qualityMonitoringInterval = null;
    }
    
    if (this.broadcasterReadyInterval) {
      clearInterval(this.broadcasterReadyInterval);
      this.broadcasterReadyInterval = null;
    }
    
    // Clear database polling
    if (this.dbPollingInterval) {
      clearInterval(this.dbPollingInterval);
      this.dbPollingInterval = null;
    }
    
    // Clear full scan interval
    if (this.fullScanInterval) {
      clearInterval(this.fullScanInterval);
      this.fullScanInterval = null;
    }

    // Clear health check and reconnection
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
    
    if (this.reconnectTimeout) {
      clearTimeout(this.reconnectTimeout);
      this.reconnectTimeout = null;
    }

    this.offerRetryTimers.forEach(timer => clearTimeout(timer));
    this.offerRetryTimers.clear();

    this.peerConnections.forEach((pc) => pc.close());
    this.peerConnections.clear();

    if (this.channel) {
      this.channel.unsubscribe();
      this.channel = null;
    }

    if (this.dbSignalingChannel) {
      this.dbSignalingChannel.unsubscribe();
      this.dbSignalingChannel = null;
    }

    this.viewerMetadata.clear();
    this.retryAttempts.clear();
    this.answerReceived.clear();
    this.offerAcked.clear();
    this.connectionQuality.clear();
  }

  async resetStream(supabase: any) {
    console.log('♻️ Resetting broadcast for stream', this.streamId);

    // 1. Close all peer connections
    this.peerConnections.forEach((pc, sessionToken) => {
      try {
        pc.close();
      } catch (e) {
        console.warn('Error closing PC for', sessionToken, e);
      }
    });
    this.peerConnections.clear();
    this.viewerMetadata.clear();
    this.retryAttempts.clear();
    this.answerReceived.clear();
    this.offerAcked.clear();
    this.connectionQuality.clear();

    // 2. Close realtime and DB signaling channels
    if (this.channel) {
      await this.channel.unsubscribe();
      this.channel = null;
    }
    if (this.dbSignalingChannel) {
      await this.dbSignalingChannel.unsubscribe();
      this.dbSignalingChannel = null;
    }

    // 3. Clear signaling rows and viewer sessions in DB for this stream
    try {
      await supabase
        .from('webrtc_signals')
        .delete()
        .eq('stream_id', this.streamId);

      await supabase
        .from('stream_viewer_sessions')
        .delete()
        .eq('stream_id', this.streamId);

      console.log('✓ Cleared signaling and viewer sessions for stream', this.streamId);
    } catch (err) {
      console.error('❌ Error clearing stream state:', err);
    }

    // 4. Re-initialize channel so new viewers can join cleanly
    await this.initializeChannel(supabase);
  }

  getViewerCount(): number {
    return Array.from(this.peerConnections.values()).filter(
      pc => pc.connectionState === 'connected'
    ).length;
  }

  async manuallyAnnounceReady(): Promise<void> {
    console.log('📢 Manually announcing broadcaster-ready');
    if (this.channel) {
      await this.sendSignal('broadcaster-ready', { streamId: this.streamId });
    }
  }

  getViewers(): Array<{ sessionToken: string; name: string; joinedAt: Date; connectionState: string; isGuest: boolean }> {
    return Array.from(this.peerConnections.entries()).map(([sessionToken, pc]) => ({
      sessionToken,
      name: this.viewerMetadata.get(sessionToken)?.name || 'Unknown',
      joinedAt: this.viewerMetadata.get(sessionToken)?.joinedAt || new Date(),
      connectionState: pc.connectionState,
      isGuest: this.viewerMetadata.get(sessionToken)?.isGuest || false
    }));
  }

  hasTURN(): boolean {
    return this.iceConfig?.hasTURN || false;
  }

  isChannelSubscribed(): boolean {
    return this.channel?.state === 'joined';
  }
}
