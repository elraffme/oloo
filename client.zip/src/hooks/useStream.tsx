import { useState, useRef, useEffect } from "react";
import { Device } from "mediasoup-client";
import { io } from "socket.io-client";

const SERVER_URL = "http://localhost:5001";

export const useStream = (navigation = null) => {
  const [socket, setSocket] = useState(null);
  const [peers, setPeers] = useState([]);
  const [localStream, setLocalStream] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [cameraFace, setCameraFace] = useState("user");
  const [remoteStream, setRemoteStream] = useState(null);


  const device = useRef(null);
  const produceTransport = useRef(null);
  const consumeTransports = useRef(new Map());
  const consumers = useRef(new Map());
  const peerId = useRef(crypto.randomUUID());
  const roomId = useRef("");
  const roleRef = useRef("viewer");
  const socketRef = useRef();
  const localStreamRef = useRef();
  const remotePeerId = useRef("");

  function cleanup() {
    produceTransport.current?.close();
    consumeTransports.current.forEach((transport) => transport?.close());
    localStreamRef.current?.getTracks().forEach((track) => track?.stop());
    socketRef.current?.disconnect();
  }

  async function loadDevice(routerRtpCapabilities) {
    try {
      device.current = new Device();
      await device.current.load({ routerRtpCapabilities });
    } catch (error) {
      console.error("Error loading device:", error);
    }
  }

  async function handleProducerTransport(data) {
    try {
      produceTransport.current = device.current.createSendTransport(data.data);

      produceTransport.current.on("connect", ({ dtlsParameters }, callback) => {
        socket.emit(
          "connectTransport",
          { dtlsParameters, id: peerId.current },
          callback
        );
      });

      produceTransport.current.on("connectionstatechange", (state) => {
        switch (state) {
          case "connecting":
            console.log("connecting");
            break;
          case "connected":
            console.log("connected");
            break;
          case "failed":
            console.log("failed");
            socket.emit(
              "producerRestartIce",
              peerId.current,
              async (params) => {
                await produceTransport.current.restartIce({
                  iceParameters: params,
                });
              }
            );
            break;
          default:
            break;
        }
      });

      produceTransport.current.on(
        "produce",
        ({ kind, rtpParameters }, callback) => {
          socket.emit(
            "produce",
            { kind, rtpParameters, id: peerId.current, room: roomId.current },
            ({ producerId }) => {
              callback({ id: producerId });
            }
          );
        }
      );

      const stream = localStreamRef.current;
      if (!stream) {
        console.log("Local stream not initialized");
        return;
      }

      const videoTrack = stream.getVideoTracks()[0];
      const audioTrack = stream.getAudioTracks()[0];

      if (audioTrack) {
        await produceTransport.current.produce({ track: audioTrack,
         });
      }
      if (videoTrack) {
        await produceTransport.current.produce({ track: videoTrack,
                  encodings: [
                {
                  ssrc: 111110,
                  scalabilityMode: "L3T3_KEY",
                  maxBitrate: 1000000,
                },
              ],
         });
      }
    } catch (error) {
      console.error("Error creating producer transport:", error);
    }
  }

  function startConsumeProducer(producer) {
    console.log("new proda came", producer);
    socket.emit("createConsumeTransport", {
      producer,
      id: peerId.current,
      room: roomId.current,
    });
  }

  async function consume(data) {
    try {
      const transport = device.current.createRecvTransport(data.data);
      consumeTransports.current.set(data.storageId, transport);

      transport.on("connect", ({ dtlsParameters }, callback) => {
        socket.emit(
          "transportConnect",
          { dtlsParameters, storageId: data.storageId },
          callback
        );
      });

      transport.on("connectionstatechange", (state) => {
        switch (state) {
          case "connecting":
            console.log("Connecting To Stream!");
            break;
          case "connected":
            console.log("subscribed!");
            break;
          case "failed":
            console.log("Failed!");
            socket.emit(
              "consumerRestartIce",
              data.storageId,
              async (params) => {
                await transport.restartIce({
                  iceParameters: params,
                });
              }
            );
            break;
          default:
            break;
        }
      });

      socket.emit("startConsuming", {
        rtpCapabilities: device.current.rtpCapabilities,
        storageId: data.storageId,
        producerId: data.producer.producerId,
        peerId: data.producer.peerId,
        room: roomId.current,
      });
    } catch (error) {
      console.error("Error creating consumer transport:", error);
    }
  }

  async function handleNewConsumer(data) {
    const {
      producerId,
      id,
      kind,
      rtpParameters,
      storageId,
      peerId: remPeerId,
    } = data;
    const transport = consumeTransports.current.get(storageId);
    if (!transport) return;

    const consumer = await transport.consume({
      id,
      producerId,
      kind,
      rtpParameters,
    });
    consumers.current.set(consumer.id, consumer);
    remotePeerId.current = remPeerId;

    console.log("new consumer", consumer.kind);

    const newStream = new MediaStream(
      Array.from(consumers.current.values()).map((c) => c.track)
    );
    setRemoteStream(newStream);
  }

  async function initialize(role, options = {}, liveId, existingStream = null) {
    roleRef.current = role;

    roomId.current = liveId;

    if (role === "streamer") {
      try {
        if (existingStream) {
           console.log("Using existing stream as local stream");
           localStreamRef.current = existingStream;
           setLocalStream(existingStream);
           setIsMuted(false);
           setCameraFace("user");
        } else {
            const stream = await navigator.mediaDevices.getUserMedia({
              audio: true,
              video: true,
            });

            setIsMuted(false);
            setCameraFace("user");
            setLocalStream(stream);
            localStreamRef.current = stream;
        }
      } catch (error) {
        console.log("Error getting user media:", error);
      }
    }

      const newSocket = io(SERVER_URL);
      socketRef.current = newSocket;
      setSocket(newSocket);
  }

  useEffect(() => {
    if (!socket) return;

    socket.on("connect", () => {
      console.log("connected socket");
      setIsConnected(true);
      socket.emit("getRTPCapabilites", async (data) => {
        console.log('emit recvd')
        await loadDevice(data.capabilities);
        socket.emit("addUserCall", {
          room: roomId.current,
          peerId: peerId.current,
          username: "User",
          type: roleRef.current,
        });
        if (roleRef.current === "streamer") {
          socket.emit("createTransport", peerId.current);
        }
      });
    });

    return () => {
      socket.off("connect");
    };
  }, [socket]);

  useEffect(() => {
    return () => {
      cleanup();
    };
  }, []);

  useEffect(() => {
    if (!socket) return;
    socket.on("transportCreated", handleProducerTransport);
    return () => {
      socket.off("transportCreated");
    };
  }, [socket]);

  useEffect(() => {
    if (!socket) return;
    socket.on("currentProducers", (producers) => {
      producers.forEach((producer) => startConsumeProducer(producer));
    });
    return () => {
      socket.off("currentProducers");
    };
  }, [socket]);

  useEffect(() => {
    if (!socket) return;
    socket.on("newProducer", startConsumeProducer);
    return () => {
      socket.off("newProducer");
    };
  }, [socket]);

  useEffect(() => {
    if (!socket) return;
    socket.on("ConsumeTransportCreated", consume);
    return () => {
      socket.off("ConsumeTransportCreated");
    };
  }, [socket]);

  useEffect(() => {
    if (!socket) return;
    socket.on("consumerCreated", handleNewConsumer);
    return () => {
      socket.off("consumerCreated");
    };
  }, [socket]);

  useEffect(() => {
    if (!socket) return;
    socket.on("userLeft", (leftPeer) => {
      if (leftPeer?.peerId === remotePeerId.current) {
        remotePeerId.current = null;
        setRemoteStream(null);
        cleanup();
        consumers.current = new Set();
        console.log("navigated----------->");
        if (navigation) {
          navigation?.navigate("Home");
        }
      }
    });
    return () => {
      socket.off("userLeft");
    };
  }, [socket]);


  function toggleCamera() {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack._switchCamera();
        setCameraFace((prev) => (prev === "user" ? "environment" : "user"));
      }
    }
  }

  function toggleMute() {
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = !track.enabled;
        setIsMuted(!track.enabled);
      });
    }
  }


  function checkChannelHealth() {
    return { isHealthy: isConnected, details: {} };
  }

  function getViewerCount() {
    return 0; // Placeholder as actual count comes from socket
  }

  return {
    initialize,
    cleanup,
    isConnected,
    localStream,
    peers,
    toggleCamera,
    toggleMute,
    isMuted,
    cameraFace,
    remoteStream,
    checkChannelHealth,
    getViewerCount
  };
};
